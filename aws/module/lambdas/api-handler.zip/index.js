"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const api_1 = require("@mcma/api");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const aws_api_gateway_1 = require("@mcma/aws-api-gateway");
const worker_invoker_1 = require("@mcma/worker-invoker");
const data_1 = require("@mcma/data");
const core_1 = require("@mcma/core");
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_lambda_1.LambdaClient({}));
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new core_1.ConsoleLoggerProvider("workflow-service-api-handler");
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
async function processNotification(requestContext) {
    const request = requestContext.request;
    const table = await dbTableProvider.get((0, data_1.getTableName)());
    const jobAssignmentDatabaseId = "/job-assignments/" + request.pathVariables.id;
    const jobAssignment = await table.get(jobAssignmentDatabaseId);
    if (!jobAssignment) {
        requestContext.setResponseResourceNotFound();
        return;
    }
    const notification = requestContext.getRequestBody();
    if (!notification) {
        requestContext.setResponseBadRequestDueToMissingBody();
        return;
    }
    if (!notification.content) {
        requestContext.setResponseError(api_1.HttpStatusCode.BadRequest, "Missing notification content");
        return;
    }
    if (!notification.content.status) {
        requestContext.setResponseError(api_1.HttpStatusCode.BadRequest, "Missing notification content status");
        return;
    }
    const taskToken = request.queryStringParameters.taskToken;
    if (!taskToken) {
        requestContext.setResponseError(api_1.HttpStatusCode.BadRequest, "Missing 'taskToken' query string parameter");
        return;
    }
    await workerInvoker.invoke((0, worker_invoker_1.getWorkerFunctionId)(), {
        operationName: "ProcessNotification",
        input: {
            jobAssignmentDatabaseId,
            notification,
            taskToken,
        },
        tracker: jobAssignment.tracker,
    });
}
const routes = new api_1.DefaultJobRouteCollection(dbTableProvider, workerInvoker)
    .addRoute("POST", "/job-assignments/{id}/notifications", processNotification);
const restController = new aws_api_gateway_1.ApiGatewayApiController(routes, loggerProvider);
async function handler(event, context) {
    console.log(JSON.stringify(event, null, 2));
    console.log(JSON.stringify(context, null, 2));
    const logger = await loggerProvider.get(context.awsRequestId);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        return await restController.handleRequest(event, context);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.awsRequestId);
    }
}
