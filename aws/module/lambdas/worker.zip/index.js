"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_cloudwatch_events_1 = require("@aws-sdk/client-cloudwatch-events");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_sfn_1 = require("@aws-sdk/client-sfn");
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_client_1 = require("@mcma/aws-client");
const operations_1 = require("./operations");
const cloudWatchLogsClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const cloudWatchEventsClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_cloudwatch_events_1.CloudWatchEventsClient({}));
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const sfnClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_sfn_1.SFNClient({}));
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)());
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("workflow-service-worker", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const providerCollection = new worker_1.ProviderCollection({
    authProvider,
    dbTableProvider,
    loggerProvider,
    resourceManagerProvider
});
const worker = new worker_1.Worker(providerCollection)
    .addOperation("ProcessCancel", operations_1.processCancel)
    .addOperation("ProcessJobAssignment", operations_1.processJobAssignment)
    .addOperation("ProcessNotification", operations_1.processNotification);
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId, event.tracker);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        await worker.doWork(new worker_1.WorkerRequest(event, logger), {
            awsRequestId: context.awsRequestId,
            sfnClient,
            cloudWatchEventsClient,
        });
    }
    catch (error) {
        logger.error("Error occurred when handling operation '" + event.operationName + "'");
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}
