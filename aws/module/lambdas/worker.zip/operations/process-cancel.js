"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processCancel = processCancel;
const client_sfn_1 = require("@aws-sdk/client-sfn");
const worker_1 = require("@mcma/worker");
const data_1 = require("@mcma/data");
const core_1 = require("@mcma/core");
async function processCancel(providers, workerRequest, context) {
    const table = await providers.dbTableProvider.get((0, data_1.getTableName)());
    const resourceManager = providers.resourceManagerProvider.get();
    const jobAssignmentHelper = new worker_1.ProcessJobAssignmentHelper(table, resourceManager, workerRequest);
    const logger = jobAssignmentHelper.logger;
    const mutex = table.createMutex({
        name: jobAssignmentHelper.jobAssignmentDatabaseId,
        holder: context.awsRequestId,
        logger,
    });
    await mutex.lock();
    try {
        await jobAssignmentHelper.initialize();
        if (jobAssignmentHelper.jobAssignment.status === core_1.JobStatus.Completed ||
            jobAssignmentHelper.jobAssignment.status === core_1.JobStatus.Failed ||
            jobAssignmentHelper.jobAssignment.status === core_1.JobStatus.Canceled) {
            return;
        }
        await context.sfnClient.send(new client_sfn_1.StopExecutionCommand({
            executionArn: jobAssignmentHelper.jobOutput.executionArn
        }));
        await jobAssignmentHelper.cancel();
    }
    catch (error) {
        logger.error(error);
        try {
            await jobAssignmentHelper.fail(new core_1.ProblemDetail({
                type: "uri://mcma.ebu.ch/rfc7807/step-functions-workflow-service/generic-error",
                title: "Generic Error",
                detail: "Unexpected error occurred: " + error.message,
                stacktrace: error.stacktrace,
            }));
        }
        catch (inner) {
            workerRequest.logger?.error(inner.toString());
        }
    }
    finally {
        await mutex.unlock();
    }
}
