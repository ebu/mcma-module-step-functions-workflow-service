"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processJobAssignment = processJobAssignment;
const uuid_1 = require("uuid");
const client_sfn_1 = require("@aws-sdk/client-sfn");
const core_1 = require("@mcma/core");
const worker_1 = require("@mcma/worker");
const data_1 = require("@mcma/data");
const common_1 = require("@local/common");
const { CLOUD_WATCH_EVENT_RULE } = process.env;
async function processJobAssignment(providers, workerRequest, context) {
    if (!workerRequest) {
        throw new core_1.McmaException("request must be provided");
    }
    if (!workerRequest.input) {
        throw new core_1.McmaException("request.input is required");
    }
    if (!workerRequest.input.jobAssignmentDatabaseId) {
        throw new core_1.McmaException("request.input does not specify a jobAssignmentDatabaseId");
    }
    const table = await providers.dbTableProvider.get((0, data_1.getTableName)());
    const resourceManager = providers.resourceManagerProvider.get();
    const jobAssignmentHelper = new worker_1.ProcessJobAssignmentHelper(table, resourceManager, workerRequest);
    const logger = jobAssignmentHelper.logger;
    const mutex = table.createMutex({
        name: jobAssignmentHelper.jobAssignmentDatabaseId,
        holder: context.awsRequestId,
        logger,
    });
    await mutex.lock();
    try {
        workerRequest.logger?.info("Initializing job helper...");
        const { Running } = core_1.JobStatus;
        await jobAssignmentHelper.initialize(Running);
        workerRequest.logger?.info("Validating job...");
        if (jobAssignmentHelper.job["@type"] !== "WorkflowJob") {
            throw new core_1.McmaException("Job has type '" + jobAssignmentHelper.job["@type"] + "', which does not match expected job type 'WorkflowJob'.");
        }
        const selectedWorkflow = await getWorkflowByName(table, jobAssignmentHelper.profile.name);
        jobAssignmentHelper.validateJob();
        workerRequest.logger?.info("Found handler for job profile '" + jobAssignmentHelper.profile.name + "'");
        await executeWorkflow(providers, jobAssignmentHelper, context, selectedWorkflow);
        workerRequest.logger?.info("Handler for job profile '" + jobAssignmentHelper.profile.name + "' completed");
    }
    catch (e) {
        workerRequest.logger?.error(e.message);
        workerRequest.logger?.error(e.toString());
        try {
            await jobAssignmentHelper.fail(new core_1.ProblemDetail({
                type: "uri://mcma.ebu.ch/rfc7807/generic-job-failure",
                title: "Generic job failure",
                detail: e.message
            }));
        }
        catch (inner) {
            workerRequest.logger?.error(inner.toString());
        }
    }
    finally {
        await mutex.unlock();
    }
}
async function getWorkflowByName(table, workflowName) {
    const workflows = await getWorkflows(table);
    const selectedWorkflow = workflows.find(wf => wf.name === workflowName);
    if (!selectedWorkflow) {
        throw new core_1.McmaException(`JobProfile '${workflowName}' is not supported.`);
    }
    return selectedWorkflow;
}
async function getWorkflows(table) {
    const workflows = [];
    const queryParams = {
        path: "/workflows",
        pageStartToken: undefined
    };
    do {
        const result = await table.query(queryParams);
        workflows.push(...result.results);
        queryParams.pageStartToken = result.nextPageStartToken;
    } while (queryParams.pageStartToken);
    return workflows;
}
async function executeWorkflow(providers, jobAssignmentHelper, context, workflow) {
    const logger = jobAssignmentHelper.logger;
    const workflowInput = {
        input: jobAssignmentHelper.jobInput,
        notificationEndpoint: new core_1.NotificationEndpoint({
            httpEndpoint: jobAssignmentHelper.jobAssignment.id + "/notifications"
        }),
        tracker: jobAssignmentHelper.jobAssignment.tracker
    };
    logger.info("Starting execution of workflow '" + workflow.name + "' with input:");
    logger.info(workflowInput);
    const data = await context.sfnClient.send(new client_sfn_1.StartExecutionCommand({
        input: JSON.stringify(workflowInput),
        stateMachineArn: workflow.stateMachineArn
    }));
    const workflowExecutionId = "/workflow-executions/" + (0, uuid_1.v4)();
    await jobAssignmentHelper.dbTable.put(workflowExecutionId, {
        id: workflowExecutionId,
        executionArn: data.executionArn,
        workerRequest: {
            operationName: jobAssignmentHelper.workerRequest.operationName,
            input: jobAssignmentHelper.workerRequest.input,
            tracker: jobAssignmentHelper.workerRequest.tracker,
        }
    });
    await (0, common_1.enableEventRule)(CLOUD_WATCH_EVENT_RULE, jobAssignmentHelper.dbTable, context.cloudWatchEventsClient, context.awsRequestId, logger);
    jobAssignmentHelper.jobOutput.executionArn = data.executionArn;
    await jobAssignmentHelper.updateJobAssignmentOutput();
}
