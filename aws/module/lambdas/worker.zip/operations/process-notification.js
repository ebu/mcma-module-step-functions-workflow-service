"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processNotification = processNotification;
const client_sfn_1 = require("@aws-sdk/client-sfn");
const core_1 = require("@mcma/core");
async function processNotification(providers, workerRequest, context) {
    const notification = workerRequest.input.notification;
    const taskToken = workerRequest.input.taskToken;
    switch (notification.content.status) {
        case core_1.JobStatus.Completed: {
            await context.sfnClient.send(new client_sfn_1.SendTaskSuccessCommand({
                taskToken: taskToken,
                output: JSON.stringify(notification.source)
            }));
            break;
        }
        case core_1.JobStatus.Failed: {
            const error = "JobFailed";
            const cause = JSON.stringify(notification.content);
            await context.sfnClient.send(new client_sfn_1.SendTaskFailureCommand({
                taskToken: taskToken,
                error: error,
                cause: cause
            }));
            break;
        }
        case core_1.JobStatus.Canceled: {
            const error = "JobCanceled";
            const cause = JSON.stringify(notification.content);
            await context.sfnClient.send(new client_sfn_1.SendTaskFailureCommand({
                taskToken: taskToken,
                error: error,
                cause: cause
            }));
            break;
        }
    }
}
